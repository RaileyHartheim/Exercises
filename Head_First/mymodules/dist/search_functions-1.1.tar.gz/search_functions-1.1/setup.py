from setuptools import setup

setup(
        name="search_functions",
        version ='1.1',
        description="Search functions from Head First Python",
        author="HF Python 2e",
        py_modules=['search_functions'],
)