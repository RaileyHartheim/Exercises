Documentation for functions in 'search_functions' module:

 search_for_vowels:
	Function returns vowels that were found in typed word
    
 search_for_letters:
	Function returns a set of letters from "letters" set that were found in typed phrase